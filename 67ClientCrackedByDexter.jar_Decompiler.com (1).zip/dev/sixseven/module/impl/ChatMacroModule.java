package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.KeybindSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.StringSetting;
import net.minecraft.class_310;
import net.minecraft.class_408;

public class ChatMacroModule extends Module {
   private static final int SLOTS = 3;
   public final ModeSetting slot = (ModeSetting)this.addSetting(new ModeSetting("Slot", "Macro slot to edit.", "1", new String[]{"1", "2", "3"}));
   public final BooleanSetting sendInstantly = (BooleanSetting)this.addSetting(new BooleanSetting("Send Instantly", "Skip the chat preview and send immediately.", true));
   private final StringSetting[] messages = new StringSetting[3];
   private final KeybindSetting[] keys = new KeybindSetting[3];

   public ChatMacroModule() {
      super("ChatMacro", "Bindable chat command macros.", Category.CLIENT);

      for(int i = 0; i < 3; ++i) {
         String num = Integer.toString(i + 1);
         this.messages[i] = (StringSetting)this.addSetting(new StringSetting("Message null", "Message or /command for slot null", "", 256, "/say hi"));
         this.keys[i] = (KeybindSetting)this.addSetting(new KeybindSetting("Key null", "Key that runs slot null", -1));
         this.messages[i].visibleWhen(() -> this.slot.check(num));
         this.keys[i].visibleWhen(() -> this.slot.check(num));
      }

   }

   public boolean onKeyPress(int keyCode) {
      boolean handled = false;

      for(int i = 0; i < 3; ++i) {
         if (this.keys[i].matches(keyCode)) {
            this.run((String)this.messages[i].get());
            handled = true;
         }
      }

      return handled;
   }

   private void run(String message) {
      if (message != null && !message.isBlank()) {
         class_310 mc = class_310.method_1551();
         if (mc.field_1724 != null && mc.field_1724.field_3944 != null) {
            if (!(Boolean)this.sendInstantly.get()) {
               mc.method_1507(new class_408(message, false));
            } else if (message.startsWith("/")) {
               mc.field_1724.field_3944.method_45730(message.substring(1));
            } else {
               mc.field_1724.field_3944.method_45729(message);
            }
         }
      }

   }
}
