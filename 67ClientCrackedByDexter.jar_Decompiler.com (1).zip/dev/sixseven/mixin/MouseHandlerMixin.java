package dev.sixseven.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.sixseven.SixSevenClient;
import dev.sixseven.hud.HudDragController;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.util.CpsTracker;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_312.class})
public class MouseHandlerMixin {
   @Shadow
   private double field_1789;
   @Shadow
   private double field_1787;

   @Inject(
      method = {"method_1606"},
      at = {@At("HEAD")}
   )
   private void sixsevenclient$aimAssist(double d, CallbackInfo ci) {
      ModuleManager modules = SixSevenClient.modules();
      if (modules != null && modules.aimAssist != null && modules.aimAssist.isEnabled()) {
         double[] add = modules.aimAssist.computePixels(d, this.field_1789, this.field_1787);
         if (add != null) {
            this.field_1789 += add[0];
            this.field_1787 += add[1];
         }
      }

   }

   @Inject(
      method = {"method_1601(JLnet/minecraft/class_11910;I)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void sixsevenclient$onButton(long window, class_11910 buttonInfo, int action, CallbackInfo ci) {
      class_310 minecraft = class_310.method_1551();
      if (window == minecraft.method_22683().method_4490()) {
         if (action == 1 && minecraft.field_1755 == null) {
            CpsTracker.onClick(buttonInfo.comp_4801());
         }

         if (minecraft.field_1755 instanceof class_408 && buttonInfo.comp_4801() == 0 && SixSevenClient.hud() != null) {
            if (action == 1) {
               if (HudDragController.tryStartDrag(SixSevenClient.hud())) {
                  ci.cancel();
               }
            } else if (action == 0 && HudDragController.isDragging()) {
               HudDragController.stopDrag();
               SixSevenClient.config().save();
               ci.cancel();
            }
         }
      }

   }

   @ModifyExpressionValue(
      method = {"method_1606"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_7172;method_41753()Ljava/lang/Object;"
)},
      slice = {@Slice(
   from = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_315;method_42495()Lnet/minecraft/class_7172;"
)
)}
   )
   private Object sixsevenclient$zoomSensitivity(Object original) {
      ModuleManager modules = SixSevenClient.modules();
      if (modules != null && modules.zoom != null && original instanceof Double s) {
         double factor = modules.zoom.currentFactor();
         if (factor <= 1.0001) {
            return original;
         } else {
            double e = s * 0.6 + 0.2;
            double scaled = e / Math.cbrt(factor);
            double substitute = (scaled - 0.2) / 0.6;
            return Math.max((double)0.0F, substitute);
         }
      } else {
         return original;
      }
   }

   @Inject(
      method = {"method_1598(JDD)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void sixsevenclient$onScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
      class_310 minecraft = class_310.method_1551();
      if (window == minecraft.method_22683().method_4490() && minecraft.field_1755 instanceof class_408 && SixSevenClient.hud() != null && HudDragController.tryResize(SixSevenClient.hud(), yOffset)) {
         ci.cancel();
      }

   }
}
