package dev.sixseven.gui.widget;

import dev.sixseven.gui.ClickGuiScreen;
import dev.sixseven.render.nanovg.NVGRenderer;
import dev.sixseven.settings.BlockListSetting;
import dev.sixseven.theme.Theme;
import dev.sixseven.theme.ThemeManager;
import dev.sixseven.util.Colors;
import dev.sixseven.util.UiSounds;
import net.minecraft.class_310;
import net.minecraft.class_437;

public class BlockListWidget extends SettingWidget {
   private static final float ROW = 26.0F;
   private BlockListSetting setting;

   public BlockListWidget(ThemeManager themes, BlockListSetting setting) {
      super(themes, setting);
      this.setting = setting;
   }

   public float height(NVGRenderer vg) {
      return 26.0F;
   }

   public void render(NVGRenderer vg, float mx, float my) {
      Theme theme = this.theme();
      float cy = this.floatVal2 + 13.0F;
      vg.text(this.setting.getName(), this.floatVal, cy, 12.5F, theme.textMuted());
      float bx = this.floatVal + this.width - 88.0F;
      float by = cy - 9.0F;
      boolean hovered = mx >= bx && mx <= bx + 88.0F && my >= by && my <= by + 18.0F;
      vg.rectGradient(bx, by, 88.0F, 18.0F, 9.0F, theme.headerTop(), theme.headerBottom(), true);
      vg.rectOutline(bx, by, 88.0F, 18.0F, 9.0F, 1.1F, Colors.withAlpha(hovered ? theme.accentBright() : theme.accent(), hovered ? 0.9F : 0.4F));
      float tw = vg.textWidth("Pick Block", 12.0F);
      vg.textGradient("Pick Block", bx + (88.0F - tw) / 2.0F, by + 9.0F, 12.0F, theme.accentBright(), theme.accent());
      long var10000 = this.setting.enabledCount();
      String count = var10000 + "/" + this.setting.size();
      vg.text(count, bx - 8.0F - vg.textWidth(count, 11.5F), cy, 11.5F, theme.textDisabled());
   }

   public boolean mouseClicked(float mx, float my, int button) {
      if (button == 0 && this.contains(mx, my)) {
         class_437 var5 = class_310.method_1551().field_1755;
         if (var5 instanceof ClickGuiScreen) {
            ClickGuiScreen gui = (ClickGuiScreen)var5;
            gui.openBlockPicker(this.setting);
            UiSounds.select();
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }
}
