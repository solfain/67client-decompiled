package dev.sixseven.gui;

import dev.sixseven.SixSevenClient;
import dev.sixseven.module.impl.GambleRiggerModule;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.class_480;

public final class GambleRiggerOverlay {
   private GambleRiggerOverlay() {
   }

   public static void register() {
      ScreenEvents.AFTER_INIT.register((ScreenEvents.AfterInit)(client, screen, scaledWidth, scaledHeight) -> {
         if (screen instanceof class_480 container) {
            GambleRiggerModule mod = SixSevenClient.modules() == null ? null : SixSevenClient.modules().gambleRigger;
            if (mod != null && mod.isEnabled()) {
               GamblePanel panel = new GamblePanel(container, mod);
               ScreenEvents.afterRender(screen).register((ScreenEvents.AfterRender)(s, graphics, mouseX, mouseY, tickDelta) -> panel.render(graphics, mouseX, mouseY));
               ScreenMouseEvents.allowMouseClick(screen).register((ScreenMouseEvents.AllowMouseClick)(s, ctx) -> !panel.handleClick(ctx.comp_4798(), ctx.comp_4799(), ctx.method_74245()));
            }
         }

      });
   }
}
