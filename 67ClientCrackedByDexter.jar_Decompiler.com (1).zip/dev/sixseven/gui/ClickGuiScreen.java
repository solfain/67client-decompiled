package dev.sixseven.gui;

import dev.sixseven.SixSevenClient;
import dev.sixseven.gui.config.ConfigPanel;
import dev.sixseven.gui.panel.CategoryPanel;
import dev.sixseven.gui.panel.Panel;
import dev.sixseven.gui.panel.ThemesPanel;
import dev.sixseven.gui.picker.BlockGridModel;
import dev.sixseven.gui.picker.IconListGridModel;
import dev.sixseven.module.Category;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.Modules;
import dev.sixseven.module.impl.BlockEspModule;
import dev.sixseven.render.BlurHook;
import dev.sixseven.render.NvgDrawable;
import dev.sixseven.render.OverlayRenderer;
import dev.sixseven.render.anim.Animation;
import dev.sixseven.render.nanovg.NVGRenderer;
import dev.sixseven.settings.BlockListSetting;
import dev.sixseven.settings.IconListSetting;
import dev.sixseven.theme.Theme;
import dev.sixseven.theme.ThemeManager;
import dev.sixseven.util.Colors;
import dev.sixseven.util.UiSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ClickGuiScreen extends class_437 implements NvgDrawable {
   private static final ClickGuiState STATE = new ClickGuiState();
   private final List<Panel> panels;
   private final Animation openAnim;
   private boolean closing;
   private final ConfigPanel configPanel;
   private static final float FIDGET_W = 118.0F;
   private static final float FIDGET_H = 28.0F;
   private boolean fidgetHovered;
   private static final float SEARCH_W = 280.0F;
   private static final float SEARCH_H = 32.0F;
   private final StringBuilder search;
   private boolean searchFocused;
   private Panel dragging;
   private float dragOffsetX;
   private float dragOffsetY;
   private float pressX;
   private float pressY;
   private boolean dragMoved;
   private Panel pressedContentPanel;
   private class_437 parent;

   public ClickGuiScreen() {
      this((class_437)null);
   }

   public ClickGuiScreen(class_437 parent) {
      super(class_2561.method_43470("Client ClickGUI"));
      this.panels = new ArrayList();
      this.openAnim = new Animation(180.0F, 0.0F);
      this.configPanel = new ConfigPanel();
      this.search = new StringBuilder();
      this.parent = parent;
      STATE.ensureDefaultLayout(OverlayRenderer.uiWidth(), OverlayRenderer.uiHeight());
      ModuleManager modules = SixSevenClient.modules();
      ThemeManager themes = SixSevenClient.themes();

      for(Category category : Category.values()) {
         this.panels.add(new CategoryPanel(category, modules, themes, STATE));
      }

      this.panels.add(new ThemesPanel(themes, STATE));
      this.openAnim.setTarget(1.0F);
   }

   public void method_49589() {
      super.method_49589();
      UiSounds.guiOpen();
   }

   public static ClickGuiState state() {
      return STATE;
   }

   private Modules.ClickGuiModule guiModule() {
      return SixSevenClient.modules().clickGui;
   }

   public boolean method_25421() {
      return false;
   }

   public void method_25419() {
      if (!this.closing) {
         this.closing = true;
         this.openAnim.setTarget(0.0F);
         UiSounds.guiClose();
      }

   }

   public void method_25432() {
      BlurHook.clear();
      SixSevenClient.config().save();
   }

   public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
      int alpha = (int)(48.0F * this.openAnim.value());
      guiGraphics.method_25294(0, 0, this.field_22789, this.field_22790, alpha << 24 | 394506);
      this.finishCloseIfDone();
   }

   public void method_25393() {
      this.finishCloseIfDone();
   }

   private void finishCloseIfDone() {
      if (this.closing && this.openAnim.isDone()) {
         this.field_22787.method_1507(this.parent);
      }

   }

   public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
      if (this.field_22787.field_1687 == null) {
         this.method_57728(guiGraphics, partialTick);
      }

      if ((Boolean)this.guiModule().blur.get()) {
         BlurHook.set(this.guiModule().blurStrength.getFloat() * this.openAnim.value());
         guiGraphics.method_71278();
      } else {
         BlurHook.clear();
      }

   }

   public void renderNvg(NVGRenderer vg, float mouseX, float mouseY, float uiWidth, float uiHeight) {
      vg.setFontMode((String)this.guiModule().font.get());
      if (vg.hasFont()) {
         float t = this.openAnim.value();
         if (!(t <= 0.002F) || !this.closing) {
            vg.save();
            vg.alpha(t);
            float scale = 0.96F + 0.04F * t;
            vg.translate(uiWidth / 2.0F, uiHeight / 2.0F);
            vg.scale(scale);
            vg.translate(-uiWidth / 2.0F, -uiHeight / 2.0F);
            String query = this.search.toString();

            for(Panel panel : this.panels) {
               if (panel instanceof CategoryPanel) {
                  CategoryPanel categoryPanel = (CategoryPanel)panel;
                  categoryPanel.setFilter(query);
               }
            }

            for(int i = this.panels.size() - 1; i >= 0; --i) {
               ((Panel)this.panels.get(i)).render(vg, mouseX, mouseY, uiWidth, uiHeight);
            }

            this.renderSearchBar(vg, uiWidth);
            this.renderFidget(vg, mouseX, mouseY, uiWidth, uiHeight);
            this.configPanel.render(vg, mouseX, mouseY, uiWidth, uiHeight);
            vg.restore();
         }
      }

   }

   private void renderFidget(NVGRenderer vg, float mouseX, float mouseY, float uiWidth, float uiHeight) {
      Theme theme = SixSevenClient.themes().current();
      float fx = fidgetX(uiWidth);
      float fy = fidgetY(uiHeight);
      boolean hover = mouseX >= fx && mouseX <= fx + 118.0F && mouseY >= fy && mouseY <= fy + 28.0F;
      boolean lit = hover || this.configPanel.isOpen();
      if (lit != this.fidgetHovered) {
         this.fidgetHovered = lit;
         if (lit) {
            UiSounds.hover();
         }
      }

      vg.glow(fx, fy, 118.0F, 28.0F, 14.0F, lit ? 7.0F : 4.0F, Colors.withAlpha(theme.accent(), lit ? 0.28F : 0.14F));
      vg.rectGradient(fx, fy, 118.0F, 28.0F, 14.0F, theme.headerTop(), theme.headerBottom(), true);
      vg.rectOutline(fx, fy, 118.0F, 28.0F, 14.0F, 1.2F, Colors.withAlpha(lit ? theme.accentBright() : theme.accent(), lit ? 0.9F : 0.4F));
      float gx = fx + 16.0F;
      float gy = fy + 14.0F - 6.0F;
      vg.rect(gx + 3.0F, gy + 3.0F, 11.0F, 9.0F, 2.5F, Colors.withAlpha(theme.accent(), 0.5F));
      vg.rect(gx, gy, 11.0F, 9.0F, 2.5F, lit ? theme.accentBright() : theme.accent());
      vg.text("Configs", fx + 36.0F, fy + 14.0F, 13.5F, lit ? theme.textPrimary() : theme.textMuted());
   }

   private static float fidgetX(float uiWidth) {
      return (uiWidth - 118.0F) / 2.0F;
   }

   private static float fidgetY(float uiHeight) {
      return uiHeight - 28.0F - 14.0F;
   }

   private boolean fidgetHit(float mx, float my) {
      float fx = fidgetX(OverlayRenderer.uiWidth());
      float fy = fidgetY(OverlayRenderer.uiHeight());
      return mx >= fx && mx <= fx + 118.0F && my >= fy && my <= fy + 28.0F;
   }

   private void renderSearchBar(NVGRenderer vg, float uiWidth) {
      Theme theme = SixSevenClient.themes().current();
      float sx = (uiWidth - 280.0F) / 2.0F;
      vg.glow(sx, 19.0F, 280.0F, 32.0F, 16.0F, 6.0F, Colors.withAlpha(theme.accent(), this.searchFocused ? 0.25F : 0.12F));
      vg.rectGradient(sx, 19.0F, 280.0F, 32.0F, 16.0F, theme.headerTop(), theme.headerBottom(), true);
      vg.rectOutline(sx, 19.0F, 280.0F, 32.0F, 16.0F, 1.2F, Colors.withAlpha(this.searchFocused ? theme.accentBright() : theme.accent(), this.searchFocused ? 0.9F : 0.4F));
      float ix = sx + 16.0F;
      float iy = 35.0F;
      vg.circleOutline(ix, iy - 1.5F, 4.5F, 1.6F, theme.textMuted());
      vg.line(ix + 3.4F, iy + 2.2F, ix + 6.5F, iy + 5.4F, 1.6F, theme.textMuted());
      float textX = sx + 30.0F;
      if (this.search.isEmpty() && !this.searchFocused) {
         vg.text("CrackedByDexter", textX, iy, 13.0F, theme.textDisabled());
      } else {
         float w = vg.text(this.search.toString(), textX, iy, 13.0F, theme.textPrimary());
         if (this.searchFocused && System.nanoTime() / 400000000L % 2L == 0L) {
            vg.rect(textX + w + 2.0F, iy - 7.0F, 1.5F, 14.0F, 0.75F, theme.accentBright());
         }
      }

      if (!this.search.isEmpty()) {
         vg.cross(sx + 280.0F - 26.0F, iy - 6.0F, 12.0F, 1.6F, theme.textMuted());
      }

   }

   public void openSearch(String query) {
      this.search.setLength(0);
      this.search.append(query);
      this.searchFocused = true;
   }

   public ConfigPanel configPanel() {
      return this.configPanel;
   }

   private boolean searchBarHit(float mx, float my) {
      float sx = (OverlayRenderer.uiWidth() - 280.0F) / 2.0F;
      return mx >= sx && mx <= sx + 280.0F && my >= 19.0F && my <= 51.0F;
   }

   private float uiX(double guiX) {
      return OverlayRenderer.guiToUi(guiX);
   }

   private float uiY(double guiY) {
      return OverlayRenderer.guiToUi(guiY);
   }

   public boolean method_25402(class_11909 event, boolean doubled) {
      float mx = this.uiX(event.comp_4798());
      float my = this.uiY(event.comp_4799());
      NVGRenderer vg = NVGRenderer.get();
      float uiHeight = OverlayRenderer.uiHeight();
      if (this.configPanel.isOpen()) {
         this.configPanel.mouseClicked(mx, my, event.method_74245());
         return true;
      } else if (this.fidgetHit(mx, my)) {
         this.configPanel.open();
         UiSounds.guiOpen();
         return true;
      } else if (!this.searchBarHit(mx, my)) {
         this.searchFocused = false;

         for(Panel panel : this.panels) {
            if (panel.headerHit(mx, my)) {
               this.bringToFront(panel);
               if (event.method_74245() == 0) {
                  this.dragging = panel;
                  this.dragOffsetX = mx - panel.getFloat();
                  this.dragOffsetY = my - panel.getFloat2();
                  this.pressX = mx;
                  this.pressY = my;
                  this.dragMoved = false;
               } else {
                  panel.toggleCollapsed();
                  UiSounds.panelCollapse();
               }

               return true;
            }

            if (panel.bodyHit(vg, mx, my, uiHeight)) {
               this.bringToFront(panel);
               this.pressedContentPanel = panel;
               panel.mouseClicked(mx, my, event.method_74245());
               return true;
            }
         }

         return true;
      } else {
         float clearX = (OverlayRenderer.uiWidth() + 280.0F) / 2.0F - 26.0F;
         if (!this.search.isEmpty() && mx >= clearX - 4.0F && mx <= clearX + 16.0F) {
            this.search.setLength(0);
         } else {
            this.searchFocused = true;
         }

         UiSounds.select();
         return true;
      }
   }

   public boolean method_25403(class_11909 event, double dx, double dy) {
      if (this.configPanel.isOpen()) {
         return true;
      } else {
         float mx = this.uiX(event.comp_4798());
         float my = this.uiY(event.comp_4799());
         if (this.dragging != null) {
            if (Math.abs(mx - this.pressX) + Math.abs(my - this.pressY) > 3.0F) {
               this.dragMoved = true;
            }

            if (this.dragMoved) {
               this.dragging.moveTo(mx - this.dragOffsetX, my - this.dragOffsetY);
            }

            return true;
         } else if (this.pressedContentPanel != null) {
            this.pressedContentPanel.mouseDragged(mx, my);
            return true;
         } else {
            return true;
         }
      }
   }

   public boolean method_25406(class_11909 event) {
      if (this.configPanel.isOpen()) {
         return true;
      } else if (this.dragging == null) {
         if (this.pressedContentPanel != null) {
            this.pressedContentPanel.mouseReleased();
            this.pressedContentPanel = null;
         }

         return true;
      } else {
         if (!this.dragMoved && event.method_74245() == 0) {
            this.dragging.toggleCollapsed();
            UiSounds.panelCollapse();
         } else if (this.dragMoved) {
            STATE.markCustomized();
         }

         this.dragging = null;
         return true;
      }
   }

   public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
      if (this.configPanel.isOpen()) {
         return true;
      } else {
         float mx = this.uiX(mouseX);
         float my = this.uiY(mouseY);
         NVGRenderer vg = NVGRenderer.get();
         float uiHeight = OverlayRenderer.uiHeight();

         for(Panel panel : this.panels) {
            if (panel.bodyHit(vg, mx, my, uiHeight) || panel.headerHit(mx, my)) {
               panel.onScroll(scrollY);
               return true;
            }
         }

         return true;
      }
   }

   public boolean method_25404(class_11908 event) {
      if (this.configPanel.isOpen()) {
         this.configPanel.keyPressed(event.comp_4795());
         return true;
      } else {
         for(Panel panel : this.panels) {
            if (panel.isListening()) {
               panel.keyPressed(event.comp_4795());
               return true;
            }
         }

         if (this.searchFocused) {
            switch (event.comp_4795()) {
               case 256:
                  this.search.setLength(0);
                  this.searchFocused = false;
                  break;
               case 257:
               case 335:
                  this.searchFocused = false;
                  break;
               case 259:
                  if (!this.search.isEmpty()) {
                     this.search.deleteCharAt(this.search.length() - 1);
                  }
            }

            return true;
         } else if (!event.method_74231() && !this.guiModule().getKeybind().matches(event.comp_4795())) {
            return super.method_25404(event);
         } else {
            this.method_25419();
            return true;
         }
      }
   }

   public boolean method_25400(class_11905 event) {
      if (this.configPanel.isOpen()) {
         this.configPanel.charTyped(event.comp_4793());
         return true;
      } else {
         for(Panel panel : this.panels) {
            if (panel.isListening()) {
               panel.charTyped(event.comp_4793());
               return true;
            }
         }

         if (this.searchFocused && event.method_74227()) {
            if (this.search.length() < 32) {
               this.search.append(event.method_74226());
            }

            return true;
         } else {
            return super.method_25400(event);
         }
      }
   }

   private void bringToFront(Panel panel) {
      if (this.panels.remove(panel)) {
         this.panels.addFirst(panel);
      }

   }

   public void openBlockPicker(BlockListSetting setting) {
      BlockGridModel model = new BlockGridModel(setting, () -> {
         BlockEspModule blockEsp = SixSevenClient.modules().blockEsp;
         return blockEsp != null ? (Integer)blockEsp.lineColor.get() : -16711736;
      }, "Pick Block");
      this.field_22787.method_1507(new IconPickerScreen(this, model, SixSevenClient.themes()));
   }

   public void openIconPicker(IconListSetting setting) {
      IconListGridModel model = new IconListGridModel(setting);
      this.field_22787.method_1507(new IconPickerScreen(this, model, SixSevenClient.themes()));
   }
}
